# need to load load, otherwise ZCI cannot work
loadNamespace("otel")
library(oteltest)
oteltest::runme()
