# spelling

    Code
      spelling::spell_check_package(pkg)
    Message
      DESCRIPTION does not contain 'Language' field. Defaulting to 'en-US'.
    Output
      No spelling errors found.

