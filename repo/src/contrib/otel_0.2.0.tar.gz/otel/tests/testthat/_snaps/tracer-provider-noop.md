# span_context_noop

    Code
      spc$to_http_headers()
    Output
      named character(0)

