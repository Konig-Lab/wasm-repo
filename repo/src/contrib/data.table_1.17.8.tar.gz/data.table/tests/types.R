require(data.table)
test.data.table(script="types.Rraw")
