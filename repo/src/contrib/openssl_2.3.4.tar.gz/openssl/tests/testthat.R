library(testthat)
suppressPackageStartupMessages(library(openssl))

test_check("openssl")
