//------------------------------------------------------------------------------
// AMD/Source/amd_l_aat.c: int64_t version of amd_aat
//------------------------------------------------------------------------------

// AMD, Copyright (c) 1996-2022, Timothy A. Davis, Patrick R. Amestoy, and
// Iain S. Duff.  All Rights Reserved.
// SPDX-License-Identifier: BSD-3-clause

//------------------------------------------------------------------------------


#define DLONG
#include "amd_aat.c"

