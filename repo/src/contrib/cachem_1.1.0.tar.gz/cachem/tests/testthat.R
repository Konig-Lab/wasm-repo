library(testthat)
library(cachem)

test_check("cachem")
