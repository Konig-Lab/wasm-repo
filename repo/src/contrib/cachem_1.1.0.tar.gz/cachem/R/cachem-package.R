#' @docType package
#' @useDynLib cachem, .registration = TRUE
#' @import fastmap
NULL
