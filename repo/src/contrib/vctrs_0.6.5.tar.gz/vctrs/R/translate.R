vec_normalize_encoding <- function(x) {
  .Call(vctrs_normalize_encoding, x)
}
