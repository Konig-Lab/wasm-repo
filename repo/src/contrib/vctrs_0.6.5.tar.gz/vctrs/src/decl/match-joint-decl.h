static inline r_obj* vec_joint_proxy_order(r_obj* x, r_obj* y);
static inline r_obj* vec_joint_proxy_order_independent(r_obj* x, r_obj* y);
static inline r_obj* vec_joint_proxy_order_dependent(r_obj* x, r_obj* y);
static inline r_obj* vec_joint_proxy_order_s3(r_obj* x, r_obj* y);
static inline r_obj* df_joint_proxy_order(r_obj* x, r_obj* y);
