static
r_obj* vctrs_size2_common(r_obj* x,
                          r_obj* y,
                          struct counters* counters,
                          void* data);
