[<img src="https://github.com/Bioconductor/BiocStickers/blob/devel/IRanges/IRanges.png" width="135" align="left">](https://bioconductor.org/packages/IRanges)

[<img src="https://bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="180" align="right">](https://bioconductor.org/)

**IRanges** is an R/Bioconductor package that provides the foundation of integer range manipulation in Bioconductor.

See https://bioconductor.org/packages/IRanges for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

<sub>_IRanges sticker courtesy of [Roberto Bonelli](https://github.com/Robbie90)._</sub>
