# a copy of the returned result from tl_platform() is saved here because
# tl_platforms() is a little slow and requires Internet connection
.tl_platforms = c('aarch64-linux', 'amd64-freebsd', 'amd64-netbsd',
  'armhf-linux', 'i386-freebsd', 'i386-linux', 'i386-netbsd', 'i386-solaris',
  'universal-darwin', 'windows', 'x86_64-cygwin', 'x86_64-darwinlegacy',
  'x86_64-linux', 'x86_64-linuxmusl', 'x86_64-solaris')
