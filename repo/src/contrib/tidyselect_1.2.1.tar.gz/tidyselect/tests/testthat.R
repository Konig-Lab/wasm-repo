library(testthat)
library(tidyselect)

test_check("tidyselect")
