## ----message=FALSE------------------------------------------------------------
library(GenomeInfoDb)
names(genomeStyles())

## -----------------------------------------------------------------------------
packageDescription("GenomeInfoDb")$Maintainer

