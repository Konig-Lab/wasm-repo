GENOME <- "sacCer1"
ORGANISM <- "Saccharomyces cerevisiae"
ASSEMBLED_MOLECULES <- paste0("chr", c(1:16, "M"))
CIRC_SEQS <- "chrM"

