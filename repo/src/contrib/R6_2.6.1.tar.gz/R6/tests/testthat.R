library(testthat)
library(R6)

test_check("R6")
