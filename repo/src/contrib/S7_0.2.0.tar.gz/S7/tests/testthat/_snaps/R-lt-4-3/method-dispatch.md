# method dispatch works for class_missing

    Code
      foo_wrapper()
    Condition
      Error in `S7::S7_dispatch()`:
      ! argument "xx" is missing, with no default

