library(testthat)
library(S7)

test_check("S7")
