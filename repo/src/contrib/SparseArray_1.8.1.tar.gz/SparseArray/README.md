[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**SparseArray** is an R/Bioconductor package for high-performance sparse data representation and manipulation in R.

See https://bioconductor.org/packages/SparseArray for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

