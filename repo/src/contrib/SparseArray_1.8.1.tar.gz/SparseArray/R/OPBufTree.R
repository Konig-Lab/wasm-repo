
free_global_OPBufTree <- function()
    invisible(.Call2("C_free_global_OPBufTree", PACKAGE="SparseArray"))

