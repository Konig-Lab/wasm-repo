#ifndef _TEST_H_
#define _TEST_H_

#include <Rdefines.h>

SEXP C_test(void);

#endif  /* _TEST_H_ */

