#ifndef _SPARSEARRAY_COMPLEX_METHODS_H_
#define _SPARSEARRAY_COMPLEX_METHODS_H_

#include <Rdefines.h>

SEXP C_Complex_SVT(
	SEXP z_dim,
	SEXP z_type,
	SEXP z_SVT,
	SEXP op
);

#endif  /* _SPARSEARRAY_COMPLEX_METHODS_H_ */

