#ifndef _SPARSEARRAY_MISC_METHODS_H_
#define _SPARSEARRAY_MISC_METHODS_H_

#include <Rdefines.h>

SEXP C_SVT_apply_isFUN(
	SEXP x_dim,
	SEXP x_type,
	SEXP x_SVT,
	SEXP isFUN
);

#endif  /* _SPARSEARRAY_MISC_METHODS_H_ */

