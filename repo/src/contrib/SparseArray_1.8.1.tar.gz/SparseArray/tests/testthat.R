library(testthat)
library(SparseArray)

test_check("SparseArray")
