
#ifndef R_WINFILES_H
#define R_WINFILES_H

int open_file(const char *path, int oflag);

#endif
