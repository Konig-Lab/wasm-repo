# Revdeps

## Failed to check (28)

|package              |version |error |warning |note |
|:--------------------|:-------|:-----|:-------|:----|
|bigPint              |?       |      |        |     |
|bioCancer            |?       |      |        |     |
|BiocPkgTools         |?       |      |        |     |
|cellscape            |?       |      |        |     |
|COTAN                |?       |      |        |     |
|EBImage              |?       |      |        |     |
|EGSEA                |?       |      |        |     |
|EpiCompare           |?       |      |        |     |
|flowGraph            |?       |      |        |     |
|GeneNetworkBuilder   |?       |      |        |     |
|Glimma               |?       |      |        |     |
|gSEM                 |?       |      |        |     |
|inlmisc              |?       |      |        |     |
|interacCircos        |?       |      |        |     |
|InterCellar          |?       |      |        |     |
|LACE                 |?       |      |        |     |
|leaflet.multiopacity |?       |      |        |     |
|leaflet.opacity      |?       |      |        |     |
|mapscape             |?       |      |        |     |
|MatrixQCvis          |?       |      |        |     |
|MetaVolcanoR         |?       |      |        |     |
|mindr                |?       |      |        |     |
|modchart             |?       |      |        |     |
|motifStack           |?       |      |        |     |
|octad                |?       |      |        |     |
|omicsViewer          |?       |      |        |     |
|palmid               |?       |      |        |     |
|parcats              |?       |      |        |     |

