## revdepcheck results

We checked 217 reverse dependencies (199 from CRAN + 18 from BioConductor), comparing R CMD check results across CRAN and dev versions of this package.

 * We saw 0 new problems
 * We failed to check 0 packages
