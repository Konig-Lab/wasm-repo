# bigPint

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/bigPint
* Number of recursive dependencies: 177

Run `revdepcheck::cloud_details(, "bigPint")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# bioCancer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/bioCancer
* Number of recursive dependencies: 224

Run `revdepcheck::cloud_details(, "bioCancer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# BiocPkgTools

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/BiocPkgTools
* Number of recursive dependencies: 164

Run `revdepcheck::cloud_details(, "BiocPkgTools")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# cellscape

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/cellscape
* Number of recursive dependencies: 45

Run `revdepcheck::cloud_details(, "cellscape")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# COTAN

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/COTAN
* Number of recursive dependencies: 272

Run `revdepcheck::cloud_details(, "COTAN")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# EBImage

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/EBImage
* Number of recursive dependencies: 55

Run `revdepcheck::cloud_details(, "EBImage")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# EGSEA

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/EGSEA
* Number of recursive dependencies: 200

Run `revdepcheck::cloud_details(, "EGSEA")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# EpiCompare

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/EpiCompare
* Number of recursive dependencies: 234

Run `revdepcheck::cloud_details(, "EpiCompare")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# flowGraph

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/flowGraph
* Number of recursive dependencies: 95

Run `revdepcheck::cloud_details(, "flowGraph")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# GeneNetworkBuilder

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/GeneNetworkBuilder
* Number of recursive dependencies: 98

Run `revdepcheck::cloud_details(, "GeneNetworkBuilder")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# Glimma

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/Glimma
* Number of recursive dependencies: 199

Run `revdepcheck::cloud_details(, "Glimma")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# gSEM

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/gSEM
* Number of recursive dependencies: 76

Run `revdepcheck::cloud_details(, "gSEM")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# inlmisc

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/inlmisc
* Number of recursive dependencies: 138

Run `revdepcheck::cloud_details(, "inlmisc")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# interacCircos

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/interacCircos
* Number of recursive dependencies: 35

Run `revdepcheck::cloud_details(, "interacCircos")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# InterCellar

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/InterCellar
* Number of recursive dependencies: 203

Run `revdepcheck::cloud_details(, "InterCellar")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# LACE

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/LACE
* Number of recursive dependencies: 169

Run `revdepcheck::cloud_details(, "LACE")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# leaflet.multiopacity

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/leaflet.multiopacity
* Number of recursive dependencies: 87

Run `revdepcheck::cloud_details(, "leaflet.multiopacity")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# leaflet.opacity

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/leaflet.opacity
* Number of recursive dependencies: 80

Run `revdepcheck::cloud_details(, "leaflet.opacity")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mapscape

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/mapscape
* Number of recursive dependencies: 32

Run `revdepcheck::cloud_details(, "mapscape")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MatrixQCvis

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MatrixQCvis
* Number of recursive dependencies: 185

Run `revdepcheck::cloud_details(, "MatrixQCvis")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# MetaVolcanoR

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/MetaVolcanoR
* Number of recursive dependencies: 120

Run `revdepcheck::cloud_details(, "MetaVolcanoR")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# mindr

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/mindr
* Number of recursive dependencies: 32

Run `revdepcheck::cloud_details(, "mindr")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# modchart

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/modchart
* Number of recursive dependencies: 123

Run `revdepcheck::cloud_details(, "modchart")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# motifStack

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/motifStack
* Number of recursive dependencies: 147

Run `revdepcheck::cloud_details(, "motifStack")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# octad

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/octad
* Number of recursive dependencies: 180

Run `revdepcheck::cloud_details(, "octad")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# omicsViewer

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/omicsViewer
* Number of recursive dependencies: 191

Run `revdepcheck::cloud_details(, "omicsViewer")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# palmid

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/palmid
* Number of recursive dependencies: 128

Run `revdepcheck::cloud_details(, "palmid")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
# parcats

<details>

* Version: NA
* GitHub: NA
* Source code: https://github.com/cran/parcats
* Number of recursive dependencies: 99

Run `revdepcheck::cloud_details(, "parcats")` for more info

</details>

## Error before installation

### Devel

```






```
### CRAN

```






```
