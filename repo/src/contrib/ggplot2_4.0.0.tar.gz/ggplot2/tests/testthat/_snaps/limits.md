# limits() throw meaningful errors

    All arguments must be named.

---

    `linewidth` must be a vector of length 2, not length 1.

