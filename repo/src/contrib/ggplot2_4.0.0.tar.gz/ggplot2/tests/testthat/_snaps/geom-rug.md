# Rug length needs unit object

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! `length` must be a <unit> object, not the number 0.01.

# geom_rug() warns about missing values when na.rm = FALSE

    Removed 2 rows containing missing values or values outside the scale range (`geom_rug()`).

