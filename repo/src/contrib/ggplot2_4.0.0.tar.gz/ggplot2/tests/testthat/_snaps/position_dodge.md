# position_dodge warns about missing required aesthetics

    Code
      ggplot_build(p)
    Condition
      Error:
      ! Problem while computing position.
      i Error occurred in the 1st layer.
      Caused by error in `setup_params()`:
      ! `position_dodge()` requires the following missing aesthetics: x or xmin.

