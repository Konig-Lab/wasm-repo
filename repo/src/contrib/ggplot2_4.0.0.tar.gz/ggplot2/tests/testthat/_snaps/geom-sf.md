# geom_sf() removes rows containing missing aes

    Removed 1 row containing missing values or values outside the scale range (`geom_sf()`).

---

    Removed 1 row containing missing values or values outside the scale range (`geom_sf()`).

---

    Removed 1 row containing missing values or values outside the scale range (`geom_sf()`).

# errors are correctly triggered

    Problem while converting geom to grob.
    i Error occurred in the 1st layer.
    Caused by error in `draw_panel()`:
    ! `geom_sf()` can only be used with `coord_sf()`.

---

    Ignoring unknown parameters: `nudge_x`

---

    Ignoring unknown parameters: `nudge_x`

---

    Removed 1 row containing missing values or values outside the scale range (`geom_sf()`).

