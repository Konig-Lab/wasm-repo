# cut_interval throws the correct error message

    Specify exactly one of `n` and `length`.

