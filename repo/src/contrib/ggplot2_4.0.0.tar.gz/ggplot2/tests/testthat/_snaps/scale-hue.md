# scale_hue() checks the type input

    `type` must be a character vector or list of character vectors, not an integer vector.

