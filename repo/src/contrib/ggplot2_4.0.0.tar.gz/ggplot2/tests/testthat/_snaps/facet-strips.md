# facet_grid() warns about bad switch input

    `switch` must be one of "both", "x", or "y", not "z".

