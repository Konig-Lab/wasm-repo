# stat_density handles data outside of `bounds`

    Some data points are outside of `bounds`. Removing them.

# stat_density works in both directions

    Problem while computing stat.
    i Error occurred in the 1st layer.
    Caused by error in `setup_params()`:
    ! `stat_density()` requires an x or y aesthetic.

# compute_density returns useful df and throws warning when <2 values

    Groups with fewer than two data points have been dropped.

# precompute_bandwidth() errors appropriately

    `bw` must be one of "nrd0", "nrd", "ucv", "bcv", "sj", "sj-ste", or "sj-dpi", not "foobar".

---

    `bw` must be a finite, positive number, not `Inf`.

