# collide() checks the input data

    y and ymax are undefined.

---

    `test()` requires non-overlapping x intervals.

