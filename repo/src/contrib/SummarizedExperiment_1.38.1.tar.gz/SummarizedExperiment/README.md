[<img src="https://github.com/Bioconductor/BiocStickers/blob/devel/SummarizedExperiment/SummarizedExperiment.png" width="135" align="left">](https://bioconductor.org/packages/SummarizedExperiment)

[<img src="https://bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="180" align="right">](https://bioconductor.org/)

**SummarizedExperiment** is an R/Bioconductor package that implements a container (S4 class) for matrix-like assays.

See https://bioconductor.org/packages/SummarizedExperiment for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

<sub>_SummarizedExperiment sticker courtesy of [Mike Love](https://github.com/mikelove)._</sub>
