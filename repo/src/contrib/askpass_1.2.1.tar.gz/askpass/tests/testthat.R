library(testthat)
library(askpass)

test_check("askpass")
