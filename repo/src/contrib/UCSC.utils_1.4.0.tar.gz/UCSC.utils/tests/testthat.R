library(testthat)
library(UCSC.utils)

test_check("UCSC.utils")
