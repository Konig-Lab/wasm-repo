[<img src="https://www.bioconductor.org/images/logo/jpg/bioconductor_logo_rgb.jpg" width="200" align="right"/>](https://bioconductor.org/)

**UCSC.utils** is an R/Bioconductor package that provides a set of low-level utilities to retrieve data from the UCSC Genome Browser.

See https://bioconductor.org/packages/UCSC.utils for more information including how to install the release version of the package (please refrain from installing directly from GitHub).

