.onLoad <- function(libname, pkgname)
{
    ## Set global option "UCSC.api.url" to primary URL (West Coast).
    UCSC.api.url("primary")
}

