[[cpp11::register]] int foo() { return 1 }
