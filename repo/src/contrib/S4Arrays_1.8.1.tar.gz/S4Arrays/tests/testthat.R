library(testthat)
library(S4Arrays)

test_check("S4Arrays")
