#ifndef _ABIND_H_
#define _ABIND_H_

#include <Rdefines.h>

SEXP C_abind(SEXP objects, SEXP nblock, SEXP ans_dim);

#endif  /* _ABIND_H_ */

